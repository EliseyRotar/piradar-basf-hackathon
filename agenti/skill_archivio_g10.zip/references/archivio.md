# Archivio evidenze Gruppo 10 (versione 2026-11-26)

## E01 | RICOSTRUZIONE_UCRAINA | FATTO | affidabilità A | VERIFICATO

- **FONTE**: World Bank, Commissione UE, ONU, Governo Ucraina - RDNA5
- **URL**: https://www.worldbank.org/en/news/press-release/2026/02/23/updated-ukraine-recovery-and-reconstruction-needs-assessment-released
- **DATA_FONTE**: 2026-02-23
- **PERIODO_DATI**: danni al 31/12/2025, fabbisogno 2026-2035
- **EVIDENZA**: Costo di ricostruzione e ripresa dell'Ucraina stimato in quasi 588 mld USD (oltre 500 mld EUR) nei prossimi 10 anni, quasi 3 volte il PIL nominale 2025. Priorità 2026 (incluse case distrutte) oltre 15 mld USD
- **NUMERO_CHIAVE**: quasi 588 mld USD
- **LIMITI**: Stima ferma al 31/12/2025. La guerra non è finita (vedi E20, E21): è fabbisogno, non ancora domanda
- **NOTA_INFERENZA**: IPOTESI: dopo un cessate il fuoco parte del fabbisogno per edifici e infrastrutture può diventare domanda di pannelli isolanti
- **DATA_RACCOLTA**: 2026-11-26

## E02 | NORMATIVA | FATTO | affidabilità A | VERIFICATO

- **FONTE**: Commissione UE - pagina Direttiva EPBD (UE) 2024/1275
- **URL**: https://energy.ec.europa.eu/topics/energy-efficiency/energy-performance-buildings/energy-performance-buildings-directive_en
- **DATA_FONTE**: 2024-05-08 (direttiva), pagina aggiornata 2026
- **PERIODO_DATI**: 2028-2030
- **EVIDENZA**: La direttiva rende gli edifici a emissioni zero lo standard per i nuovi edifici. Il GWP sul ciclo di vita va calcolato e indicato nell'attestato energetico da gennaio 2028 per nuovi edifici sopra 1.000 m2 e da gennaio 2030 per tutti i nuovi edifici
- **NUMERO_CHIAVE**: 2028 e 2030
- **LIMITI**: Date dello standard emissioni zero (edifici pubblici dal 1/1/2028, tutti i nuovi dal 1/1/2030) verificate su https://energy.ec.europa.eu/zero-emission-buildings_en. Recepimento italiano non verificato
- **NOTA_INFERENZA**: IPOTESI: l'impronta carbonica dell'isolante diventa criterio di scelta e favorisce sistemi PU a basso PCF
- **DATA_RACCOLTA**: 2026-11-26

## E03 | DOMANDA_EDILIZIA | FATTO | affidabilità A | VERIFICATO

- **FONTE**: Commissione UE - EPBD key facts (dati Eurostat e EEA 2023)
- **URL**: https://energy.ec.europa.eu/topics/energy-efficiency/energy-performance-buildings/energy-performance-buildings-directive_en
- **DATA_FONTE**: pagina aggiornata 2026
- **PERIODO_DATI**: dati 2023
- **EVIDENZA**: Circa il 40% dell'energia consumata nell'UE è usata negli edifici e circa il 50% del consumo di gas UE è attribuibile agli edifici. Il tasso annuo di ristrutturazione energetica resta molto basso all'1%
- **NUMERO_CHIAVE**: 40% energia, 50% gas, 1% ristrutturazioni
- **LIMITI**: Dati riferiti al 2023
- **NOTA_INFERENZA**: IPOTESI: la riqualificazione dell'involucro è un bacino di domanda ancora poco sfruttato
- **DATA_RACCOLTA**: 2026-11-26

## E04 | NORMATIVA | FATTO | affidabilità A | VERIFICATO

- **FONTE**: Commissione UE - Regolamento delegato (UE) 2026/52 sul GWP
- **URL**: https://energy.ec.europa.eu/topics/energy-efficiency/energy-performance-buildings/energy-performance-buildings-directive_en
- **DATA_FONTE**: 2026-05-04
- **PERIODO_DATI**: dal 2026
- **EVIDENZA**: Pubblicato il 4 maggio 2026 il regolamento delegato che fissa il quadro UE per il calcolo nazionale del GWP sul ciclo di vita degli edifici, con metodi comparabili tra Paesi
- **NUMERO_CHIAVE**: EU/2026/52
- **LIMITI**: Contenuto tecnico del regolamento non letto
- **NOTA_INFERENZA**: IPOTESI: i progettisti chiederanno dati di impronta carbonica certificati (EPD) per i pannelli
- **DATA_RACCOLTA**: 2026-11-26

## E05 | NORMATIVA | FATTO | affidabilità A | VERIFICATO

- **FONTE**: Commissione UE - pagina Regolamento F-gas (UE) 2024/573
- **URL**: https://climate.ec.europa.eu/eu-action/fluorinated-greenhouse-gases/f-gas-legislation_en
- **DATA_FONTE**: 2024-02-07 (adozione)
- **PERIODO_DATI**: 2024-2050
- **EVIDENZA**: Regolamento F-gas adottato il 7/02/2024 e applicato dall'11/03/2024. Le quote HFC scendono fino all'eliminazione degli HFC nell'UE nel 2050
- **NUMERO_CHIAVE**: 2050
- **LIMITI**: Il calendario dei divieti specifici per le schiume (Allegato IV) non è stato verificato. Molti pannelli continui usano già pentano: impatto da confermare
- **NOTA_INFERENZA**: IPOTESI: vantaggio per sistemi espandenti senza gas fluorurati
- **DATA_RACCOLTA**: 2026-11-26

## E06 | DOMANDA_EDILIZIA | FATTO | affidabilità A | VERIFICATO

- **FONTE**: Eurostat - Euro indicators Production in construction
- **URL**: https://ec.europa.eu/eurostat/product?code=4-20082026-ap
- **DATA_FONTE**: 2026-08-20
- **PERIODO_DATI**: giugno 2026
- **EVIDENZA**: Produzione nelle costruzioni -1,3% nell'area euro e -1,0% nell'UE a giugno 2026 su maggio. Costruzione di edifici -0,9% su maggio e -6,5% su giugno 2025 nell'area euro (-4,9% UE)
- **NUMERO_CHIAVE**: edifici -6,5% a/a
- **LIMITI**: Dato mensile volatile e rivedibile
- **NOTA_INFERENZA**: IPOTESI: la nuova costruzione di edifici è in calo marcato
- **DATA_RACCOLTA**: 2026-11-26

## E07 | DOMANDA_EDILIZIA | FATTO | affidabilità A | VERIFICATO

- **FONTE**: Eurostat - Euro indicators Production in construction
- **URL**: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/4-19112026-ap
- **DATA_FONTE**: 2026-11-19
- **PERIODO_DATI**: settembre 2026
- **EVIDENZA**: Produzione nelle costruzioni +0,1% nell'area euro e -0,5% nell'UE a settembre 2026 su agosto. Su base annua -1,5% area euro e -1,4% UE. Costruzione di edifici +0,7% su agosto ma -4,0% su settembre 2025 nell'area euro (-3,8% UE)
- **NUMERO_CHIAVE**: edifici -4,0% a/a
- **LIMITI**: Ultimo dato disponibile, rivedibile. Il prossimo comunicato è previsto il 18/12/2026
- **NOTA_INFERENZA**: IPOTESI: il calo degli edifici rallenta ma resta negativo: la domanda di pannelli per nuove costruzioni resta debole nel breve
- **DATA_RACCOLTA**: 2026-11-26

## E08 | MERCATO_PANNELLI | LIMITE | affidabilità C | DA_VERIFICARE

- **FONTE**: MarketsandMarkets - Europe Commercial Sandwich Panels
- **URL**: https://www.marketsandmarkets.com/Market-Reports/geography/commercial-sandwich-panels-market/Europe
- **DATA_FONTE**: data non indicata
- **PERIODO_DATI**: 2026-2031
- **EVIDENZA**: Mercato europeo dei pannelli sandwich commerciali circa 2,45 mld USD nel 2026, crescita annua circa 2,3% fino al 2031
- **NUMERO_CHIAVE**: 2,45 mld USD
- **LIMITI**: Pagina che blocca la lettura automatica, cifra letta da un riassunto di ricerca. Report a pagamento, solo segmento commerciale, tutti i materiali di anima. Conflitto apparente con E09 ed E10
- **DATA_RACCOLTA**: 2026-11-26

## E09 | MERCATO_PANNELLI | LIMITE | affidabilità C | VERIFICATO

- **FONTE**: MarkWide Research - Europe Sandwich Panels Market
- **URL**: https://markwideresearch.com/europe-sandwich-panels-market
- **DATA_FONTE**: data non indicata
- **PERIODO_DATI**: 2026-2035
- **EVIDENZA**: Mercato europeo dei pannelli sandwich 6,8 mld USD nel 2026, previsto 10,92 mld USD nel 2035 (crescita annua 5,40%)
- **NUMERO_CHIAVE**: 6,8 mld USD
- **LIMITI**: Report a pagamento, metodo non pubblico, perimetro totale (tutti i segmenti e materiali)
- **DATA_RACCOLTA**: 2026-11-26

## E10 | MERCATO_PANNELLI | LIMITE | affidabilità C | VERIFICATO

- **FONTE**: IMARC Group - Europe Sandwich Panels Market
- **URL**: https://www.imarcgroup.com/europe-sandwich-panels-market
- **DATA_FONTE**: data non indicata
- **PERIODO_DATI**: 2025-2034
- **EVIDENZA**: Mercato europeo dei pannelli sandwich 4,2 mld USD nel 2025, previsto 6,3 mld USD nel 2034 (crescita annua 4,30% 2026-2034)
- **NUMERO_CHIAVE**: 4,2 mld USD
- **LIMITI**: Report a pagamento, metodo non pubblico. Terza stima diversa da E08 ed E09
- **NOTA_INFERENZA**: IPOTESI: le stime private servono solo come ordine di grandezza (2-7 mld USD), la differenza dipende dal perimetro
- **DATA_RACCOLTA**: 2026-11-26

## E11 | LOGISTICA_GEOPOLITICA | FATTO | affidabilità B | VERIFICATO

- **FONTE**: Lloyd's List Intelligence - Strait of Hormuz Brief
- **URL**: https://www.lloydslistintelligence.com/resources/blog/strait-of-hormuz-brief-19-november-2026
- **DATA_FONTE**: 2026-11-19
- **PERIODO_DATI**: settembre-novembre 2026
- **EVIDENZA**: Ottobre 2026 mese con più transiti a Hormuz dall'inizio del conflitto: 550 contro 504 di settembre. UKMTO conta 163 eventi dall'inizio del conflitto all'11 novembre e 7 attacchi tra il 5 e l'11 novembre
- **NUMERO_CHIAVE**: 550 transiti, 7 attacchi in una settimana
- **LIMITI**: Situazione in evoluzione rapida, traffico ancora sotto i livelli pre-crisi
- **NOTA_INFERENZA**: IPOTESI: nello scenario base il rischio su costo e disponibilità delle materie prime petrolchimiche resta alto
- **DATA_RACCOLTA**: 2026-11-26

## E12 | MATERIE_PRIME_ENERGIA | FATTO | affidabilità A | VERIFICATO

- **FONTE**: BASF - comunicato stampa (Trade News)
- **URL**: https://www.basf.com/global/en/media/news-releases/2026/03/p-26-063
- **DATA_FONTE**: 2026-03-25
- **PERIODO_DATI**: marzo 2026
- **EVIDENZA**: BASF aumenta fino al 30% i prezzi delle ammine standard in Europa a causa dei forti aumenti di materie prime, energia e logistica dovuti al conflitto militare in Medio Oriente
- **NUMERO_CHIAVE**: fino a +30%
- **LIMITI**: Riguarda le ammine, non direttamente MDI e polioli
- **NOTA_INFERENZA**: IPOTESI: la stessa pressione di costo pesa sulle catene PU in Europa
- **DATA_RACCOLTA**: 2026-11-26

## E13 | MATERIE_PRIME_ENERGIA | INFERENZA | affidabilità B | VERIFICATO

- **FONTE**: Oxford Economics - Iran conflict adds cost pressure to energy intensive industries
- **URL**: https://www.oxfordeconomics.com/resource/iran-conflict-adds-cost-pressure-to-energy-intensive-industries/
- **DATA_FONTE**: 2026 (giorno non indicato)
- **PERIODO_DATI**: 2026
- **EVIDENZA**: La chimica è particolarmente vulnerabile perché usa idrocarburi sia come energia sia come materia prima. La chimica europea è la più esposta, con prezzi del gas quasi raddoppiati nei giorni dell'analisi
- **NUMERO_CHIAVE**: gas quasi x2
- **LIMITI**: Analisi di un istituto privato, data esatta non indicata
- **DATA_RACCOLTA**: 2026-11-26

## E14 | MATERIE_PRIME_ENERGIA | FATTO | affidabilità B | VERIFICATO

- **FONTE**: ChemAnalyst - MDI Prices Europe
- **URL**: https://www.chemanalyst.com/NewsAndDeals/NewsDetails/mdi-prices-appreciate-2-3-in-europe-as-the-production-costs-41053
- **DATA_FONTE**: 2026-02-06
- **PERIODO_DATI**: seconda metà gennaio 2026
- **EVIDENZA**: Prezzi MDI in Europa +2,3% nella seconda metà di gennaio 2026 per scarsità di offerta e aumento dei costi delle materie prime
- **NUMERO_CHIAVE**: +2,3%
- **LIMITI**: Valutazione di un servizio privato di prezzi. Dato precedente alla crisi di Hormuz
- **DATA_RACCOLTA**: 2026-11-26

## E15 | COMMERCIO_ESTERO | FATTO | affidabilità A | VERIFICATO

- **FONTE**: UN Comtrade (API pubblica) - Italia codice HS 730890
- **URL**: https://comtradeapi.un.org/public/v1/preview/C/A/HS?reporterCode=380&period=2024&partnerCode=0&cmdCode=730890&flowCode=X,M
- **DATA_FONTE**: 2026-11-26 (estrazione)
- **PERIODO_DATI**: 2023-2025
- **EVIDENZA**: Export italiano HS 730890: 1.273,8 mln USD (2023), 1.455,6 mln USD (2024), 1.436,1 mln USD (2025). Import: 610,4 mln USD (2023), 677,2 mln USD (2024)
- **NUMERO_CHIAVE**: export 2025 1.436,1 mln USD
- **LIMITI**: HS 730890 comprende tutte le strutture in acciaio, non solo pannelli (il codice UE 7308 90 51 non è in Comtrade). Dato 2025 forse provvisorio
- **NOTA_INFERENZA**: IPOTESI: l'Italia è esportatore netto, export stabile nel 2025 (-1,3% sul 2024, calcolo: 1436,1/1455,6-1)
- **DATA_RACCOLTA**: 2026-11-26

## E16 | RICOSTRUZIONE_UCRAINA | FATTO | affidabilità A | VERIFICATO

- **FONTE**: UN Comtrade (API pubblica) - Italia verso Ucraina e import Ucraina HS 730890
- **URL**: https://comtradeapi.un.org/public/v1/preview/C/A/HS?reporterCode=380&period=2024&partnerCode=804&cmdCode=730890&flowCode=X
- **DATA_FONTE**: 2026-11-26 (estrazione)
- **PERIODO_DATI**: 2021-2024
- **EVIDENZA**: Export italiano HS 730890 verso l'Ucraina: 1,3 mln USD (2021), 1,1 mln USD (2023), 2,5 mln USD (2024). Import totale ucraino HS 730890 nel 2024: 64,2 mln USD
- **NUMERO_CHIAVE**: 2,5 mln USD
- **LIMITI**: Codice ampio (strutture in acciaio). Dato import Ucraina da reporterCode=804
- **NOTA_INFERENZA**: IPOTESI: oggi l'Italia pesa circa il 4% dell'import ucraino del codice (2,5/64,2): spazio di crescita se parte la ricostruzione
- **DATA_RACCOLTA**: 2026-11-26

## E17 | COMMERCIO_ESTERO | FATTO | affidabilità A | VERIFICATO

- **FONTE**: UN Comtrade (API pubblica) - Italia codice HS 392113
- **URL**: https://comtradeapi.un.org/public/v1/preview/C/A/HS?reporterCode=380&period=2023&partnerCode=0&cmdCode=392113&flowCode=X
- **DATA_FONTE**: 2026-11-26 (estrazione)
- **PERIODO_DATI**: 2023
- **EVIDENZA**: Export italiano di lastre cellulari di poliuretano (HS 392113) nel 2023: 207,1 mln USD
- **NUMERO_CHIAVE**: 207,1 mln USD
- **LIMITI**: Solo 2023 disponibile nell'estrazione gratuita
- **DATA_RACCOLTA**: 2026-11-26

## E18 | BIO_CIRCOLARE | FATTO | affidabilità A | VERIFICATO

- **FONTE**: BASF - comunicato UTECH 2021
- **URL**: https://www.basf.com/global/en/media/news-releases/2021/11/p-21-373
- **DATA_FONTE**: 2021-11-12
- **PERIODO_DATI**: 2021
- **EVIDENZA**: BASF dichiara che i sistemi PU per pannelli sandwich Elastopor ed Elastopir da materie prime rinnovabili hanno la stessa qualità di quelli convenzionali. Con il Biomass Balance le risorse fossili possono essere sostituite fino al 100% da materie prime rinnovabili
- **NUMERO_CHIAVE**: fino al 100%
- **LIMITI**: Dichiarazione aziendale del 2021 (oltre 24 mesi). Bilancio di massa: quota rinnovabile attribuita per calcolo, non misurata nel prodotto
- **NOTA_INFERENZA**: IPOTESI: BASF ha già un'offerta bio-attributed drop-in per i pannellisti
- **DATA_RACCOLTA**: 2026-11-26

## E19 | BIO_CIRCOLARE | FATTO | affidabilità A | VERIFICATO

- **FONTE**: BASF - comunicato pannelli Falk
- **URL**: https://www.basf.com/global/en/media/news-releases/2017/02/p-17-123
- **DATA_FONTE**: 2017-02-06
- **PERIODO_DATI**: 2017
- **EVIDENZA**: Il produttore olandese di pannelli Falk usa sistemi BASF a bilancio di biomassa. La quota rinnovabile va dal 25 al 100% a scelta del cliente ed è attribuita con metodo certificato da TÜV SÜD
- **NUMERO_CHIAVE**: 25-100%
- **LIMITI**: Fonte del 2017: prova che l'offerta esiste da anni, non dice nulla sulla domanda attuale
- **DATA_RACCOLTA**: 2026-11-26

## E20 | RICOSTRUZIONE_UCRAINA | FATTO | affidabilità B | VERIFICATO

- **FONTE**: PRIO Peace Research Institute Oslo - commento
- **URL**: https://www.prio.org/comments/1933
- **DATA_FONTE**: 2026-11-17
- **PERIODO_DATI**: novembre 2026
- **EVIDENZA**: I colloqui diretti Russia-Ucraina-USA ad Abu Dhabi del 10-11 novembre 2026, dopo nove mesi di pausa, hanno prodotto un accordo di principio su uno scambio di prigionieri ma nessuna svolta su cessate il fuoco, territori o sicurezza
- **NUMERO_CHIAVE**: nessun cessate il fuoco
- **LIMITI**: Commento di un istituto di ricerca
- **NOTA_INFERENZA**: IPOTESI: la fine della guerra resta uno scenario ipotetico, non lo scenario base
- **DATA_RACCOLTA**: 2026-11-26

## E21 | RICOSTRUZIONE_UCRAINA | FATTO | affidabilità B | VERIFICATO

- **FONTE**: Al Jazeera
- **URL**: https://www.aljazeera.com/news/2026/11/17/ukraine-holds-peace-talks-with-us-europe-as-conflict-escalates
- **DATA_FONTE**: 2026-11-17
- **PERIODO_DATI**: novembre 2026
- **EVIDENZA**: Il Cremlino dichiara di volere una pace duratura e non un cessate il fuoco temporaneo. Ucraina, USA e partner europei concordano un incontro a Berlino con la Coalizione dei volenterosi
- **NUMERO_CHIAVE**: nessun cessate il fuoco
- **LIMITI**: Notizia in evoluzione
- **DATA_RACCOLTA**: 2026-11-26

## E22 | MATERIE_PRIME_ENERGIA | LIMITE | affidabilità - | MANCANTE

- **FONTE**: Ricerca su fonti gratuite
- **PERIODO_DATI**: ottobre-novembre 2026
- **EVIDENZA**: NON TROVATO: prezzo effettivo pagato per MDI e polioli in Europa a ottobre-novembre 2026
- **LIMITI**: I prezzi effettivi sono a pagamento. Disponibili solo annunci di listino (E27) e commenti (E28)
- **DATA_RACCOLTA**: 2026-11-26

## E23 | DOMANDA_EDILIZIA | FATTO | affidabilità B | VERIFICATO

- **FONTE**: EU Construction Platform (Commissione UE) su dati Eurostat
- **URL**: https://transition-pathways.europa.eu/construction/news/eu-construction-output-rises-april-2026-eurostat-reports
- **DATA_FONTE**: 2026-08-04
- **PERIODO_DATI**: aprile 2026
- **EVIDENZA**: Ad aprile 2026 la costruzione di edifici cala dello 0,1% su marzo e del 5,2% su aprile 2025 nell'area euro (-3,2% UE), mentre genio civile e lavori specializzati crescono
- **NUMERO_CHIAVE**: edifici -5,2% a/a
- **LIMITI**: Portale UE che riprende Eurostat. Dato superato da E06 ed E07
- **NOTA_INFERENZA**: IPOTESI: il calo degli edifici è continuo da almeno aprile a settembre 2026 (E23, E06, E07)
- **DATA_RACCOLTA**: 2026-11-26

## E24 | DOMANDA_EDILIZIA | FATTO | affidabilità B | DA_VERIFICARE

- **FONTE**: CBRE - Italy Industrial and Logistics Market Figures Q3 2026
- **URL**: https://www.cbre.com/insights/figures/italy-industrial-logistics-market-figures-q3-2026
- **DATA_FONTE**: 2026-10-21
- **PERIODO_DATI**: Q3 2026
- **EVIDENZA**: Assorbimento di spazi industriali e logistici in Italia di circa 811.000 m2 nel terzo trimestre 2026, record per un terzo trimestre
- **NUMERO_CHIAVE**: circa 811.000 m2
- **LIMITI**: Pagina non leggibile in automatico: numero ripreso dall'archivio del team. Misura spazi affittati, non pannelli venduti
- **NOTA_INFERENZA**: IPOTESI: la logistica italiana è un segmento di domanda di pannelli più forte dell'edilizia generale
- **DATA_RACCOLTA**: 2026-11-26

## E25 | DOMANDA_EDILIZIA | INFERENZA | affidabilità B | VERIFICATO

- **FONTE**: Italian Datacenter Association via The Next Web
- **URL**: https://thenextweb.com/news/italy-data-centre-investment-37-billion
- **DATA_FONTE**: 2026-10-08
- **PERIODO_DATI**: 2025-2036 (previsione)
- **EVIDENZA**: L'associazione italiana dei data center prevede che la capacità dei data center commerciali italiani cresca di cinque volte fino a 2,3 GW entro il 2031, con investimenti fino a 36,9 mld EUR entro il 2036
- **NUMERO_CHIAVE**: 2,3 GW al 2031
- **LIMITI**: Previsione di un'associazione di categoria interessata, non un dato consuntivo
- **NOTA_INFERENZA**: IPOTESI: i data center sono un segmento in crescita per pannelli PIR con alte prestazioni al fuoco
- **DATA_RACCOLTA**: 2026-11-26

## E26 | DOMANDA_EDILIZIA | INFERENZA | affidabilità B | VERIFICATO

- **FONTE**: Savills - Pan-European occupier themes 2026
- **URL**: https://www.savills.com/research_articles/255800/386469-0
- **DATA_FONTE**: 2026
- **PERIODO_DATI**: 2026
- **EVIDENZA**: In Europa occidentale cresce la richiesta di magazzini con catena del freddo da parte di alimentare e farmaceutico, con più attività anche nei mercati del Sud Europa
- **NUMERO_CHIAVE**: qualitativo
- **LIMITI**: Dato qualitativo, senza numeri, non specifico per l'Italia
- **NOTA_INFERENZA**: IPOTESI: la catena del freddo è un segmento prioritario per pannelli ad alto isolamento
- **DATA_RACCOLTA**: 2026-11-26

## E27 | MATERIE_PRIME_ENERGIA | FATTO | affidabilità B | DA_VERIFICARE

- **FONTE**: ECHEMI - annunci prezzi poliuretani Europa
- **URL**: https://www.echemi.com/cms/3206779.html
- **DATA_FONTE**: 2026-08-27
- **PERIODO_DATI**: agosto 2026
- **EVIDENZA**: Dow annuncia aumenti sui prodotti poliuretanici in Europa, Medio Oriente, Africa e India dal 26/08/2026. Huntsman applica +250 EUR/t sull'MDI in Europa dal 1/08/2026
- **NUMERO_CHIAVE**: +250 EUR/t MDI
- **LIMITI**: Pagina non leggibile in automatico, dato confermato da una seconda ricerca. Sono annunci di listino, non prezzi pagati
- **NOTA_INFERENZA**: IPOTESI: i margini dei pannellisti sono sotto pressione per il costo MDI
- **DATA_RACCOLTA**: 2026-11-26

## E28 | MATERIE_PRIME_ENERGIA | FATTO | affidabilità B | VERIFICATO

- **FONTE**: Argus Media - podcast poliuretani e isocianati (EUROPUR 2026)
- **URL**: https://www.argusmedia.com/en/news-and-insights/energy-and-commodity-podcasts/chemical-conversations-polyurethanes-isocyanates-europur-2026
- **DATA_FONTE**: 2026-06-02
- **PERIODO_DATI**: da inizio guerra USA-Iran
- **EVIDENZA**: Un'analista Argus osserva in Europa una prima reazione ai forti rincari di TDI e MDI avvenuti dall'inizio della guerra USA-Iran
- **NUMERO_CHIAVE**: rincari forti, numeri non pubblici
- **LIMITI**: Estratto di un podcast, valori numerici non disponibili gratis
- **NOTA_INFERENZA**: IPOTESI: i rincari sono legati alla guerra e potrebbero ridursi se la crisi si attenua
- **DATA_RACCOLTA**: 2026-11-26

## E29 | MATERIE_PRIME_ENERGIA | INFERENZA | affidabilità B | VERIFICATO

- **FONTE**: Fastmarkets - CBAM e acciaio
- **URL**: https://www.fastmarkets.com/insights/inside-the-default-benchmark-spread-reshaping-eu-steel-trade/
- **DATA_FONTE**: 2026-08-14
- **PERIODO_DATI**: 2026-2035
- **EVIDENZA**: Con i valori di default CBAM il dazio effettivo medio sul coil laminato a caldo importato supera il 15% nel 2026 salvo verifica delle emissioni, e i costi sono destinati a crescere molto fino al 2035
- **NUMERO_CHIAVE**: oltre 15%
- **LIMITI**: Stima di analisti, dipende dal prezzo del carbonio e dall'origine dell'acciaio
- **NOTA_INFERENZA**: IPOTESI: anche le lamiere dei pannelli costano di più, quindi i pannellisti sono più attenti al prezzo dei sistemi chimici
- **DATA_RACCOLTA**: 2026-11-26

## E30 | BIO_CIRCOLARE | FATTO | affidabilità A | VERIFICATO

- **FONTE**: BASF - pagina prodotto Elastopir
- **URL**: https://plastics-rubber.basf.com/emea/en/performance_polymers/products/elastopir
- **DATA_FONTE**: 2026 (pagina attuale)
- **PERIODO_DATI**: prodotto attuale
- **EVIDENZA**: Elastopir (anima PIR) ha resistenza al fuoco EN 13501-2 REI 30 con 100 mm e REI 60 con 200 mm e standard FM 4880 classe 1. Elastopir Blue è un sistema PIR a basso lambda espanso con HFO
- **NUMERO_CHIAVE**: REI 60 a 200 mm
- **LIMITI**: Dichiarazione commerciale BASF. Il valore lambda 19 mW/mK non compare sulla pagina letta
- **NOTA_INFERENZA**: IPOTESI: BASF ha già prodotti per data center e logistica (fuoco e isolamento), ma Elastopir Blue usa HFO (vedi E32)
- **DATA_RACCOLTA**: 2026-11-26

## E31 | COMMERCIO_ESTERO | LIMITE | affidabilità C | VERIFICATO

- **FONTE**: IndexBox - isocianati nell'Unione europea
- **URL**: https://www.indexbox.io/blog/isocyanates-european-union-market-overview-2024-1/
- **DATA_FONTE**: 2026-07-01
- **PERIODO_DATI**: 2024
- **EVIDENZA**: Le importazioni UE di isocianati sono scese per il terzo anno di fila, del 28,8% a 444.000 t nel 2024
- **NUMERO_CHIAVE**: 444.000 t
- **LIMITI**: Aggregatore privato e dato 2024: da ricontrollare su UN Comtrade (HS 292910)
- **NOTA_INFERENZA**: IPOTESI: l'Europa dipende meno dalle importazioni di isocianati
- **DATA_RACCOLTA**: 2026-11-26

## E32 | NORMATIVA | LIMITE | affidabilità B | DA_VERIFICARE

- **FONTE**: Environmental Investigation Agency - EU F-gas Regulation briefing
- **URL**: https://eia-international.org/wp-content/uploads/EIA-2024-EU-F-Gas-Regulations-Climate-Briefing-SPREADS.pdf
- **DATA_FONTE**: 2024
- **PERIODO_DATI**: dal 2024
- **EVIDENZA**: Secondo l'ONG il Regolamento 2024/573 elimina gli HFC entro il 2050 e molti HFO rientrano nella definizione OCSE di PFAS, base della restrizione REACH in discussione
- **NUMERO_CHIAVE**: HFO = PFAS (definizione OCSE)
- **LIMITI**: ONG con posizione di parte, PDF non riletto in automatico. Non è certo se e quando la restrizione PFAS toccherà gli espandenti dei pannelli
- **NOTA_INFERENZA**: IPOTESI: rischio normativo per sistemi espansi con HFO come Elastopir Blue (E30)
- **DATA_RACCOLTA**: 2026-11-26

## E33 | LOGISTICA_GEOPOLITICA | FATTO | affidabilità B | VERIFICATO

- **FONTE**: Al Jazeera su dati UKMTO e fonti marittime
- **URL**: https://www.aljazeera.com/news/2026/11/24/hormuz-oil-traffic-is-down-40-percent-are-irans-tanker-attacks-working
- **DATA_FONTE**: 2026-11-24
- **PERIODO_DATI**: settimana terminata il 24 novembre 2026
- **EVIDENZA**: Il traffico petrolifero attraverso Hormuz risulta inferiore del 40% e più di 25 petroliere sono state colpite nell'ultima settimana. Le navi transitano anche con AIS spento
- **NUMERO_CHIAVE**: traffico petrolifero -40%, oltre 25 petroliere colpite
- **LIMITI**: Il -40% è nel titolo: la base di confronto non è chiara. Fonte giornalistica, situazione in rapida evoluzione. Differenza con E11 per periodo (più recente) e perimetro (solo petrolio)
- **NOTA_INFERENZA**: IPOTESI: costi di trasporto, assicurazione e materie prime petrolchimiche restano sotto pressione
- **DATA_RACCOLTA**: 2026-11-26

## E34 | MATERIE_PRIME_ENERGIA | FATTO | affidabilità B | VERIFICATO

- **FONTE**: Argus Media - PMDI spread widens as demand diverges by sector
- **URL**: https://www.argusmedia.com/de/news-and-insights/latest-market-news/2907965-pmdi-spread-widens-as-demand-diverges-by-sector
- **DATA_FONTE**: 2026-11-23
- **PERIODO_DATI**: novembre 2026
- **EVIDENZA**: A novembre l'intervallo della valutazione Argus dei contratti europei di PMDI si allarga a 250 EUR/t. Il prezzo medio valutato scende, ma il PMDI per pannelli isolanti PIR resta invariato o sale di circa 20-50 EUR/t. La capacità europea di MDI era ridotta di almeno il 20% a settembre-ottobre per fermate, poi in gran parte rientrata
- **NUMERO_CHIAVE**: PIR +20-50 EUR/t, spread 250 EUR/t
- **LIMITI**: Valutazione privata, livello assoluto a pagamento. Argus parla di PIR boards (isolanti), non specificamente di pannelli sandwich
- **NOTA_INFERENZA**: IPOTESI: il segmento PIR sostiene prezzi più alti degli altri usi: per BASF è un segmento di valore da proteggere
- **DATA_RACCOLTA**: 2026-11-26

## E35 | MATERIE_PRIME_ENERGIA | FATTO | affidabilità B | VERIFICATO

- **FONTE**: Argus Media - PMDI spread widens as demand diverges by sector
- **URL**: https://www.argusmedia.com/de/news-and-insights/latest-market-news/2907965-pmdi-spread-widens-as-demand-diverges-by-sector
- **DATA_FONTE**: 2026-11-23
- **PERIODO_DATI**: settembre-ottobre 2026
- **EVIDENZA**: Il benzene a contratto è in media 1.079 EUR/t a settembre-ottobre 2026 contro 566 EUR/t un anno prima, anche per il conflitto in Medio Oriente. Il gas TTF è in media 81,10 EUR/MWh contro 31,13 EUR/MWh un anno prima
- **NUMERO_CHIAVE**: benzene 1.079 EUR/t, TTF 81,10 EUR/MWh
- **LIMITI**: Costi a monte dell'MDI, non prezzi pagati dai pannellisti. Medie di due mesi
- **NOTA_INFERENZA**: IPOTESI: i costi alti limitano i ribassi del PMDI anche con più disponibilità
- **DATA_RACCOLTA**: 2026-11-26

## E36 | MATERIE_PRIME_ENERGIA | LIMITE | affidabilità C | VERIFICATO

- **FONTE**: IMARC Group - MDI Prices
- **URL**: https://www.imarcgroup.com/methylene-diphenyl-diisocyanate-pricing-report
- **DATA_FONTE**: 2026-11-19
- **PERIODO_DATI**: novembre 2026
- **EVIDENZA**: IMARC indica un prezzo MDI in Europa di 2,41 USD/kg a novembre 2026, in aumento del 3,9%
- **NUMERO_CHIAVE**: 2,41 USD/kg, +3,9%
- **LIMITI**: Sintesi di report a pagamento, metodo e grado non spiegati. In conflitto apparente con E34 (prezzo medio Argus in calo): perimetro e metodo diversi
- **DATA_RACCOLTA**: 2026-11-26

## E37 | MATERIE_PRIME_ENERGIA | LIMITE | affidabilità C | VERIFICATO

- **FONTE**: Expert Market Research - Polyol Price Trends
- **URL**: https://www.expertmarketresearch.com/price-forecast/polyol-price-trends
- **DATA_FONTE**: 2026-09-08
- **PERIODO_DATI**: Q1-Q2 2026
- **EVIDENZA**: Il polyol in Germania costa 2.120 USD/t nel secondo trimestre 2026, +3,9% su 2.040 USD/t del primo trimestre
- **NUMERO_CHIAVE**: 2.120 USD/t
- **LIMITI**: Sintesi di report a pagamento. Prezzo misto polietere e poliestere, non specifico per schiume rigide. Dato precedente agli eventi recenti
- **DATA_RACCOLTA**: 2026-11-26

## E38 | LOGISTICA_GEOPOLITICA | FATTO | affidabilità A | VERIFICATO

- **FONTE**: U.S. Energy Information Administration (EIA)
- **URL**: https://www.eia.gov/todayinenergy/detail.php?id=65504
- **DATA_FONTE**: 2025-06-16
- **PERIODO_DATI**: 2024
- **EVIDENZA**: Nel 2024 il flusso di petrolio attraverso Hormuz è stato in media di 20 milioni di barili al giorno, circa il 20% del consumo mondiale di liquidi petroliferi
- **NUMERO_CHIAVE**: 20 mln bbl/giorno, 20%
- **LIMITI**: Dato strutturale 2024, precedente alla crisi del 2026
- **NOTA_INFERENZA**: IPOTESI: un'interruzione a Hormuz si trasmette rapidamente ai costi delle materie prime petrolchimiche
- **DATA_RACCOLTA**: 2026-11-26

## E39 | LOGISTICA_GEOPOLITICA | FATTO | affidabilità A | VERIFICATO

- **FONTE**: U.S. Energy Information Administration (EIA)
- **URL**: https://www.eia.gov/todayinenergy/detail.php?id=65584
- **DATA_FONTE**: 2025-06-24
- **PERIODO_DATI**: 2024
- **EVIDENZA**: Nel 2024 circa il 20% del commercio mondiale di LNG è transitato da Hormuz, soprattutto dal Qatar (circa 9,3 miliardi di piedi cubi al giorno) e dagli Emirati (circa 0,7)
- **NUMERO_CHIAVE**: 20% del commercio LNG
- **LIMITI**: Dato strutturale 2024. Unisce le righe E39 ed E40 proposte dall'Agente 1 (stessa fonte)
- **NOTA_INFERENZA**: IPOTESI: le restrizioni a Hormuz pesano sul gas europeo e sui costi energetici della chimica
- **DATA_RACCOLTA**: 2026-11-26

## E40 | LOGISTICA_GEOPOLITICA | FATTO | affidabilità A | VERIFICATO

- **FONTE**: U.S. Energy Information Administration (EIA)
- **URL**: https://www.eia.gov/todayinenergy/detail.php?id=61002
- **DATA_FONTE**: 2023-11-21
- **PERIODO_DATI**: 2022-2023
- **EVIDENZA**: Nel 2022 e nel primo semestre 2023 i flussi da Hormuz erano oltre un quarto del petrolio commerciato via mare. Le vie alternative sono l'oleodotto saudita East-West da 5 milioni bbl/giorno (portato temporaneamente a 7 nel 2019) e l'oleodotto degli Emirati verso Fujairah da 1,5 milioni bbl/giorno
- **NUMERO_CHIAVE**: oltre 25%, bypass 5 + 1,5 mln bbl/giorno
- **LIMITI**: Fonte di oltre 24 mesi, usata solo come dato strutturale. Unisce le righe E41 ed E42 proposte dall'Agente 1
- **NOTA_INFERENZA**: IPOTESI: la capacità di bypass è inferiore ai volumi normali dello stretto
- **DATA_RACCOLTA**: 2026-11-26
