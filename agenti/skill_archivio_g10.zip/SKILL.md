---
name: archivio-g10
description: Archivio condiviso del Gruppo 10 (hackathon BASF) con le evidenze pubbliche su pannelli sandwich PU/PIR, edilizia, normativa, materie prime, logistica, Ucraina e bio. Usala sempre per leggere le evidenze per ID (E01, E02...) con fonte, data, qualità e stato, prima di cercare o di consigliare.
---

# Archivio condiviso Gruppo 10

Questo è l'archivio condiviso tra AGENTE 1 (Research & Data Curator) e AGENTE 2 (Advisor). Versione del 2026-11-26: 40 evidenze (35 VERIFICATO, 4 DA_VERIFICARE, 1 MANCANTE).

## Dove sono i dati
- `references/archivio.md`: una scheda per evidenza, facile da leggere.
- `references/archivio.csv`: stessi dati, separatore punto e virgola.

## Campi
ID, DATA_RACCOLTA, FONTE, URL, DATA_FONTE, PERIODO_DATI, TEMA, EVIDENZA, NUMERO_CHIAVE, QUALITA, AFFIDABILITA, LIMITI, NOTA_INFERENZA, STATO.

## Regole di lettura
1. Cita sempre l'ID tra parentesi quadre, es. [E07].
2. QUALITA: FATTO = verificabile alla fonte; INFERENZA = stima o interpretazione; LIMITE = dato debole, vecchio, in conflitto o mancante.
3. AFFIDABILITA: A ufficiale o primaria; B associazioni, analisti, media specializzati; C report a pagamento o stampa generica.
4. STATO: VERIFICATO = URL aperto e numero ricontrollato; DA_VERIFICARE = non ancora controllato; MANCANTE = dato cercato e non trovato.
5. NOTA_INFERENZA è una deduzione del team (inizia con IPOTESI): non presentarla mai come fatto della fonte.
6. Se l'utente allega in chat righe più recenti (BLOCCO_HANDOFF o file), quelle si aggiungono a questo archivio: in caso di stesso ID vale la versione più recente.
7. Non inventare righe, numeri o URL che non sono qui o nel materiale allegato.
